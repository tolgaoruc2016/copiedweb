// Create closure to keep namespace clean and hide implementation.
(function ($) {
    'use strict';

    // Trigger on '5408xb' and on '5408 XB'
    var NL_SIXPP_REGEX                      = /[0-9]{4,4}\s?[a-zA-Z]{2,2}/;
    var NL_STREETNUMBER_REGEX               = /[0-9]+/;
    var NL_STREETNUMBER_WITH_ADDITION_REGEX = /[0-9]+ ?([0-9a-zA-Z]{0,3})/;

    var BE_POSTALCODE_REGEX                 = /^[1-9][0-9]{3}$/;
    var BE_STREETNAME_REGEX                 = /^[a-zA-ZÀ-ÿ0-9]+([ '-\.][a-zA-ZÀ-ÿ0-9]+)*$/;
    var BE_STREETNUMBER_REGEX               = /^[0-9]+$/;

    var FR_POSTALCODE_REGEX                 = /^[0-9]{5}$/;
    var FR_STREETNUMBER_REGEX               = /^[0-9]+(\s?(bis|ter|quater|[a-zA-Z]))?$/i;
    var FR_STREETNAME_REGEX                 = /^[\p{L}0-9]+([\s'-.][\p{L}0-9]+)*$/u;
    var FR_SETTLEMENT_REGEX                 = /^[\p{L}]+([\s'-.][\p{L}]+)*$/u;

    var DE_POSTALCODE_REGEX                 = /^[0-9]{5}$/;
    var DE_STREETNUMBER_REGEX               = /^[0-9]+(\s?(bis|ter|quater|[a-zA-Z]))?$/i;
    var DE_STREETNAME_REGEX                 = /^[\p{L}0-9]+([\s'-.][\p{L}0-9]+)*$/u;
    var DE_SETTLEMENT_REGEX                 = /^[\p{L}]+([\s'-.][\p{L}]+)*$/u;

    $.fn.applyAutocomplete = function (options) {
        if (!options) {
            options = {};
        }

        var default_args = {
            // Wait for 10 seconds before giving up on communication with
            // Pro6PP.
            'timeout':                            10000,
            // When set to 'true', the script will required a valid address
            // present in the Pro6PP database.
            // Set to 'false' to allow entering a custom address.
            'enforce_validation':                 true,
            // When set to 'true', the script will never block the process in
            // case of
            // trouble communicating with Pro6PP.
            // Set to 'false' to prevent users from entering a custom address.
            'gracefully_degrade':                 true,
            // Allow splitting streetnumber additions from streetnumbers when
            // no specific streetnumber addition field is provided.
            'allow_streetnumber_additions_split': false,
        };

        var instance = this;

        for (var index in default_args) {
            if (typeof options[index] === 'undefined') {
                instance[index] = default_args[index];
            }
        }

        function getConfig(field) {
            if (typeof options[field] === 'undefined') {
                // Use default field class name
                return instance.find('.' + field);
            } else {
                // Developer chose to specify form field manually.
                return $(options[field]);
            }
        }

        instance.lat          = getConfig('lat');
        instance.lng          = getConfig('lng');
        instance.city         = getConfig('city');
        instance.land         = getConfig('country');
        instance.street       = getConfig('street');
        instance.message      = getConfig('message');
        instance.spinner      = getConfig('spinner');
        instance.streets      = getConfig('streets');
        instance.areacode     = getConfig('areacode');
        instance.postcode     = getConfig('postcode');
        instance.province     = getConfig('province');
        instance.extension    = getConfig('extension');
        instance.municipality = getConfig('municipality');
        instance.streetnumber = getConfig('streetnumber');

        instance.shippingCity         = getConfig('shippingCity');
        instance.shippingLand         = getConfig('shippingCountry');
        instance.shippingStreet       = getConfig('shippingStreet');
        instance.shippingZipcode      = getConfig('shippingZipcode');
        instance.shippingStreetNumber = getConfig('shippingStreetNumber');

        instance.forceOrder = getConfig('forceOrder');

        instance.errorContainer         = $(options.errorContainerSelector || '#pro6pp_errors');
        instance.shippingErrorContainer = $(options.shippingErrorContainerSelector || '#pro6pp_shipping_errors');

        instance.validAddress = true;
        instance.validShippingAddress = true;
        instance.validateZipcodeNotation = options.validateZipcodeNotation === true

        // Turn off browser autocompletion for the postcode field.
        // Because javascript is unable to catch an event when a user clicks a
        // previously filled-in value that the browser may suggest.
        // The autocomplete attribute became official in HTML5, but used to work
        // long before that.
        instance.postcode.attr('autocomplete', 'off');
        instance.postcode.keyup(function () {
            autocomplete(instance, false);
        });

        instance.streetnumber.attr('autocomplete', 'off');
        instance.streetnumber.blur(function () {
            autocomplete(instance, false);
        });

        instance.street.attr('autocomplete', 'off');
        instance.street.blur(function () {
            if (resolveCountry(instance.land) !== 'NL') {
                autocomplete(instance, false);
            }
        });

        instance.shippingZipcode.attr('autocomplete', 'off');
        instance.shippingZipcode.keyup(function () {
            autocomplete(instance, true);
        });

        instance.shippingStreet.attr('autocomplete', 'off');
        instance.shippingStreet.blur(function () {
            if (resolveCountry(instance.shippingLand) !== 'NL') {
                autocomplete(instance, true);
            }
        });

        instance.shippingStreetNumber.attr('autocomplete', 'off');
        instance.shippingStreetNumber.blur(function () {
            autocomplete(instance, true);
        });

        instance.extension.attr('autocomplete', 'off');
        instance.extension.blur(function () {
            autocomplete(instance);
        });
        // Bind event handler to street selectbox.
        if (typeof instance.streets !== 'undefined') {
            // When pressing tab, make a selection.
            instance.streets.blur(function () {
                show_street(instance);
            });
        }

        instance.forceOrder.change(function (event) {
            if (event.target.checked) {
                $('.add-to-cart').prop('disabled', false);
            } else {
                const disableCart = !instance.validAddress || !instance.validShippingAddress;

                $('.add-to-cart').prop('disabled', disableCart);
            }
        })

        if (options.validateOnSubmit) {
            instance.errors = {};

            $('#' + options.formId).on('submit.applyAutocomplete', function (e) {
                e.preventDefault();

                var form = this;

                Promise.resolve(autocomplete(instance, false)).then(function () {
                    if (Object.keys(instance.errors).length === 0) {
                        if (typeof options.onValid === 'function') {
                            options.onValid(instance, form);
                        } else {
                            form.submit();
                        }
                    } else {
                        if (typeof options.onError === 'function') {
                            options.onError(instance, form);
                        }
                    }
                });
            });
        }

        function applyLandBehavior(country) {
            var isNL = country === 'NL' && authKeyConfigured();
            instance.street.prop('readonly', isNL);
            instance.city.prop('readonly', isNL);
        }

        applyLandBehavior(resolveCountry(instance.land));

        instance.land.on('change', function () {
            applyLandBehavior($(this).val());
            instance.street.val('');
            instance.city.val('');
        });

        instance.callback = options.callback;
    };

    // Forms without a country field are assumed to be NL-only.
    function resolveCountry(landField) {
        return landField.length ? landField.val() : 'NL';
    }

    // Without an auth key, Pro6PP requests always fail; skip validation entirely.
    function authKeyConfigured() {
        return typeof pro6pp_auth_key !== 'undefined' && pro6pp_auth_key !== '';
    }

    var pro6pp_cache = {};

    async function call(postalCode, params, authKey, countryCode) {
        const baseUrl = "https://api.pro6pp.nl";

        const country = countryCode.toLowerCase();
        const encodedUrl = new URL(`${baseUrl}/v2/autocomplete/${country}`);

        let queryParams = null;

        if (countryCode === 'BE') {
             queryParams = { postalCode: postalCode, street: params.street, streetNumber: params.streetnumber, authKey: authKey }
        } else if (countryCode === 'FR') {
             queryParams = { postalCode: postalCode, settlement: params.settlement, street: params.street, streetNumber: params.streetnumber, authKey: authKey }
        } else if (countryCode === 'DE') {
             queryParams = { postalCode: postalCode, settlement: params.settlement, street: params.street, streetNumber: params.streetnumber, authKey: authKey }
        } else {
             queryParams = { postalCode: postalCode, streetNumber: params.streetnumber, authKey: authKey }
        }

        encodedUrl.search = new URLSearchParams(queryParams)

        return await fetch(encodedUrl).catch((error) => {
            throw new Error(error);
        });
    }

    function pro6pp_cached_get(obj, url, params, callback, shippingAdres) {
        $('.forceOrder').prop('checked', false);

        var key = url + $.param(params);
        if (pro6pp_cache.hasOwnProperty(key)) {
            if (typeof callback !== 'undefined') {
                callback(obj, pro6pp_cache[key], shippingAdres);
            }

            handlePro6ppAlerts(obj, pro6pp_cache[key], shippingAdres);

            return Promise.resolve();
        }

        obj.spinner.show();

        return call(params.nl_sixpp, params, params.auth_key, params.country)
            .then((response) => {
                return response.json();
            })
            .then((data) => {
                pro6pp_cache[key] = data;

                if (typeof callback !== 'undefined' && data.errors === undefined) {
                    callback(obj, data, shippingAdres);
                }

                handlePro6ppAlerts(obj, data, shippingAdres);
            })
            .catch(() => {
                // Network failure or a non-JSON response: treat it the same as any
                // other Pro6PP error so readonly fields don't stay locked forever.
                handlePro6ppAlerts(obj, { errors: ['Unable to contact Pro6PP validation service'] }, shippingAdres);
            })
            .finally(() => {
                obj.spinner.hide();
            });
    }

    // Request geo-data from nl_sixpp
    function autocomplete(obj, shippingAddress) {
        if (!authKeyConfigured()) {
            return;
        }

        obj.message.hide().empty();

        let city
        let street
        let country
        let postcode
        let streetnumber

        if (shippingAddress) {
            city         = obj.shippingCity.val();
            street       = obj.shippingStreet.val();
            country      = resolveCountry(obj.shippingLand);
            postcode     = obj.shippingZipcode.val();
            streetnumber = obj.shippingStreetNumber.val();
        } else {
            city         = obj.city.val();
            street       = obj.street.val();
            country      = resolveCountry(obj.land);
            postcode     = obj.postcode.val();
            streetnumber = obj.streetnumber.val();
        }

        if (obj.validateZipcodeNotation) {
            validateCorrectZipcode(obj, country, postcode);
        }

        // Let's validate the form before submitting to pro6pp
        if (country === 'NL') {
            if (NL_SIXPP_REGEX.test(postcode) && ((typeof streetnumber === 'undefined' || NL_STREETNUMBER_REGEX.test(streetnumber))
                    ||
                    (typeof obj.addition === 'undefined' && NL_STREETNUMBER_WITH_ADDITION_REGEX.test(streetnumber)
                        && obj.allow_streetnumber_additions_split === true))
                ) {
                return sendToPro6pp(shippingAddress, obj, postcode, streetnumber)
            }
        } else if (country === 'BE') {
            if (BE_POSTALCODE_REGEX.test(postcode) && BE_STREETNUMBER_REGEX.test(streetnumber) && BE_STREETNAME_REGEX.test(street)) {
                return sendToPro6pp(shippingAddress, obj, postcode, streetnumber)
            }
        } else if (country === 'DE') {
            if (DE_POSTALCODE_REGEX.test(postcode) && DE_STREETNUMBER_REGEX.test(streetnumber) && DE_STREETNAME_REGEX.test(street) && DE_SETTLEMENT_REGEX.test(city)) {
                return sendToPro6pp(shippingAddress, obj, postcode, streetnumber, city)
            }
        } else if (country === 'FR') {
            if (FR_POSTALCODE_REGEX.test(postcode) && FR_STREETNUMBER_REGEX.test(streetnumber) && FR_STREETNAME_REGEX.test(street) && FR_SETTLEMENT_REGEX.test(city)) {
                return sendToPro6pp(shippingAddress, obj, postcode, streetnumber, city)
            }
        } else {
            // We don't support another country
            obj.street.empty();
            obj.street.empty();
        }

        return Promise.resolve();
    }

    function validateCorrectZipcode(obj, country, postcode) {
        let validZipcode;

        switch (country) {
            case 'NL':
                validZipcode = NL_SIXPP_REGEX.test(postcode);
                break;
            case 'BE':
                validZipcode = BE_POSTALCODE_REGEX.test(postcode);
                break;
            case 'DE':
                validZipcode = DE_POSTALCODE_REGEX.test(postcode);
                break;
            case 'FR':
                validZipcode = FR_POSTALCODE_REGEX.test(postcode);
                break;
        }

        if (!validZipcode) {
            showFieldError(obj, 'postcode', $.inArray(country, ['BE', 'DE', 'FR']) !== -1 ? 'Invalid be_fourpp format' : 'Invalid nl_fourpp format');
        } else {
            removeFieldError(obj, 'postcode');
        }
    }

    function sendToPro6pp(shippingAddress, obj, postcode, streetnumber, city){
        show_street(obj);

        var url    = 'https://api.pro6pp.nl/v2/autocomplete/nl';

        var params = {
            auth_key: pro6pp_auth_key,
            nl_sixpp: postcode,
        };

        // Street-number field is not required
        if (typeof obj.streetnumber !== 'undefined') {
            params.streetnumber = streetnumber;
            // Extension field is not required
            if (typeof obj.extension !== 'undefined' && obj.extension.length) {
                params.extension = obj.extension.val();
            } else if (obj.allow_streetnumber_additions_split === true) {
                var match = NL_STREETNUMBER_WITH_ADDITION_REGEX.exec(streetnumber);
                if (match !== null) {
                    params.extension = match[1];
                }
            }
        }

        if (shippingAddress){
            params.street = obj.shippingStreet.val();
            params.country = resolveCountry(obj.shippingLand);

            if (params.country === 'FR' || params.country === 'DE') {
                params.settlement = city;
            }

            return pro6pp_cached_get(obj, url, params, fillin, shippingAddress);
        } else {
            params.street = obj.street.val();
            params.country = resolveCountry(obj.land);

            if (params.country === 'FR' || params.country === 'DE') {
                params.settlement = city;
            }

            return pro6pp_cached_get(obj, url, params, fillin, shippingAddress);
        }
    }

    function show_street(obj) {
        obj.street.show();
        obj.streets.hide();
        // Copy over the selected value (if any) and remember the choice of
        // streets.
        var streetname = obj.streets.val();
        if (typeof streetname !== 'undefined' && streetname !== '') {
            obj.street.val(streetname).trigger('change');
            obj.street.data('old_streetname', streetname);
        }
    }

    function show_streets(obj) {
        obj.street.hide();
        obj.streets.show();
    }

    function escapeHtml(unsafe) {
        // Some characters that are received from the webservice should be
        // escaped when used in HTML
        return unsafe.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function fillin(obj, json, shippingAdress) {
        if (typeof obj.callback !== 'undefined') {
            obj.callback(json, shippingAdress);
        }

        var country = shippingAdress ? resolveCountry(obj.shippingLand) : resolveCountry(obj.land);

        // NL: autocomplete both street and city (both come from the API)
        // BE: autocomplete city, and use corrected street spelling/casing from the API
        // FR/DE: validation only, all fields are user-provided inputs
        var shouldFillStreet = (country === 'NL' || country === 'BE') && json.street;
        var shouldFillCity = (country === 'NL' || country === 'BE') && json.settlement;

        var $form = shippingAdress ? obj.shippingStreet.closest('form') : obj.street.closest('form');
        var validator = $form.data('validator');

        if (shippingAdress) {
            if (shouldFillCity) {
                obj.shippingCity.val(json.settlement).trigger('change');
                if (validator) validator.element(obj.shippingCity[0]);
            }
            if (shouldFillStreet) {
                obj.shippingStreet.val(json.street).trigger('change');
                if (validator) validator.element(obj.shippingStreet[0]);
            }
        } else {
            if (shouldFillStreet) {
                obj.street.val(json.street).trigger('change');
                if (validator) validator.element(obj.street[0]);
            }
            if (shouldFillCity) {
                obj.city.val(json.settlement).trigger('change');
                if (validator) validator.element(obj.city[0]);
            }
        }

        handlePro6ppAlerts(obj, json, shippingAdress);
    }

    function handlePro6ppAlerts(obj, json, shippingAdress) {
        if (json.errors === undefined) {
            if (shippingAdress) {
                obj.validShippingAddress = true;
                obj.shippingErrorContainer.css('display', 'none');
            } else {
                obj.validAddress = true;
                obj.errorContainer.css('display', 'none');
            }
        }

        if (json.error_id === 'NO_RESULTS_FOUND') {
            if (shippingAdress) {
                obj.validShippingAddress = false
                obj.shippingErrorContainer.css('display', 'block')
            } else {
                obj.validAddress = false
                obj.errorContainer.css('display', 'block')
                releaseReadOnlyFields(obj, false, true);
            }
        } else if (json.errors !== undefined && !shippingAdress) {
            // Any other error (e.g. missing/invalid auth key) means we can't
            // rely on Pro6PP, so don't leave the fields stuck as readonly.
            releaseReadOnlyFields(obj, false, true);
        }

        if (!shippingAdress && typeof obj.errors !== 'undefined') {
            if (json.error_id === 'NO_RESULTS_FOUND') {
                showFieldError(obj, 'streetnumber', 'Streetnumber not found');
            } else {
                removeFieldError(obj, 'streetnumber');
            }
        }

        const disableCart = !obj.validAddress || !obj.validShippingAddress;

        $('.add-to-cart').prop('disabled', disableCart);
        $('.confirm-address').css('display', disableCart ? 'block': 'none');
    }
    function showErrorMessage(obj, message, printError = true) {
        var translated_message = message;
        // See if we've got a translation available
        switch (message) {
            case 'nl_sixpp not found':
                translated_message = 'Onbekende postcode';
                releaseReadOnlyFields(obj, false, true);
                break;
            case 'Invalid nl_sixpp format':
                translated_message = 'Ongeldig postcode formaat';
                break;
            case 'streetnumber is missing a number':
                translated_message = 'Vul een geldig huisnummer in';
                break;
            case 'Streetnumber not found':
                translated_message = 'Adres niet gevonden, weet u zeker dat het klopt?';
                releaseReadOnlyFields(obj, false, true);
                break;
            case 'extension not found':
                translated_message = 'Onbekende huisnummerextensie';
                releaseReadOnlyFields(obj, false, true);
                break;
            case 'Invalid nl_fourpp format':
                translated_message = 'Ongeldig postcode formaat';
                break;
            case 'Invalid be_fourpp format':
                translated_message = 'Ongeldig postcode formaat';
                releaseReadOnlyFields(obj, false, true);
                break;
            case 'Unable to contact Pro6PP validation service':
                translated_message = 'Geen verbinding met validatieserver';
                releaseReadOnlyFields(obj, false, true);
                break;

            default:
                translated_message = 'Geen verbinding met validatieserver';
                releaseReadOnlyFields(obj, false, true);
                break;
        }

        if (printError) {
            // Show message to user
            obj.message.html(translated_message).show();
        } else {
            return translated_message;
        }
    }

    function showFieldError(obj, field, message) {
        let error = showErrorMessage(obj, message, false);
        obj[field].parent().find('.error').html(error).removeClass('checked').show();

        obj.errors[field] = error;
    }

    function removeFieldError(obj, field) {
        obj[field].parent().find('.error').empty().hide();

        delete obj.errors[field];
    }

    function releaseReadOnlyFields(obj, not_found, comm_error) {
        if (comm_error === true && obj.gracefully_degrade === false) {
            return;
        }
        if (not_found === true && obj.enforce_validation === true) {
            return;
        }

        // Make input fields writable.
        obj.street.removeAttr('readonly');
        obj.city.removeAttr('readonly');
    }

    //
    // end of closure
    //
})(jQuery);
