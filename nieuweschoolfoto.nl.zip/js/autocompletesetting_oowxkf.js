var pro6pp_auth_key = 'u6TRO4q6esrxhvZ6';
$(document).ready(function () {
    $('.address').applyAutocomplete();
});
